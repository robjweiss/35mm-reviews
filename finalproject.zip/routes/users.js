const express = require("express");
const router = express.Router();
const data = require("../data");
const usersData = data.users;

module.exports = router;