# 35mm-reviews
A simple web app for reviewing and rating movies built on Node.JS and Express

### Running the app
- Install the required packages in the `packages.json`
- To seed the database with data type `npm run seed`
- You can run the project with `npm start`
