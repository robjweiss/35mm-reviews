const usersData = require("./users");
const reviewsData = require("./reviews");
const loginData = require("./login");
module.exports = {
    users: usersData,
    reviews: reviewsData,
	login: loginData
};